def max(x: Int, y: Int): Int =
  if (y < x) x
  else y

def min(x: Int, y: Int): Int =
  if (x < y) x
  else y