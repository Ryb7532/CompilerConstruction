def test(x: Int, y: Int): Int = x - x / y * y

