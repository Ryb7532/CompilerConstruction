def test(x: Int, y: Int, z: Int) : Int = (x - y) * z

